/*
 * rtc_ds1302.c
 *
 * Driver pro RTC modul DS1302 (3-wire interface).
 * Implementuje standardní rozhraní rtc.h pro tento projekt.
 */

#include "rtc.h"
#include <avr/io.h>
#include <util/delay.h>

/* --- KONFIGURACE PINŮ (Dle tvého zadání) --- */
#define DS_PORT PORTB
#define DS_DDR  DDRB
#define DS_PIN  PINB

#define PIN_CE   3  /* Chip Enable (RST) */
#define PIN_IO   4  /* Data I/O (DAT) */
#define PIN_SCLK 5  /* Serial Clock (CLK) */

/* Příkazy DS1302 */
#define CMD_READ_BURST  0xBF
#define CMD_WRITE_BURST 0xBE
#define CMD_WRITE_WP    0x8E
#define CMD_WRITE_SEC   0x80
#define CMD_READ_SEC    0x81

/* --- Makra pro ovládání pinů --- */
#define CE_HIGH()    (DS_PORT |= (1 << PIN_CE))
#define CE_LOW()     (DS_PORT &= ~(1 << PIN_CE))
#define SCLK_HIGH()  (DS_PORT |= (1 << PIN_SCLK))
#define SCLK_LOW()   (DS_PORT &= ~(1 << PIN_SCLK))
#define IO_HIGH()    (DS_PORT |= (1 << PIN_IO))
#define IO_LOW()     (DS_PORT &= ~(1 << PIN_IO))

#define IO_OUTPUT()  (DS_DDR |= (1 << PIN_IO))
#define IO_INPUT()   (DS_DDR &= ~(1 << PIN_IO))
#define IO_READ()    ((DS_PIN & (1 << PIN_IO)) ? 1 : 0)

/* Pomocné funkce pro BCD */
static uint8_t bcd2bin(uint8_t val) { return val - 6 * (val >> 4); }
static uint8_t bin2bcd(uint8_t val) { return val + 6 * (val / 10); }

/* --- Low Level komunikace --- */

/* Zapíše bajt do DS1302 (LSB first) */
static void ds1302_write_byte(uint8_t data)
{
    IO_OUTPUT();
    for (uint8_t i = 0; i < 8; i++) {
        /* Nastav data na IO */
        if (data & 0x01) IO_HIGH();
        else             IO_LOW();
        
        /* Pulz hodinami (Data se zapisují na náběžnou hranu) */
        /* DS1302 vyžaduje data validní před náběžnou hranou */
        _delay_us(1); 
        SCLK_HIGH();
        _delay_us(1);
        SCLK_LOW(); // Shazujeme dolů pro další bit
        
        data >>= 1;
    }
}

/* Přečte bajt z DS1302 (LSB first) */
static uint8_t ds1302_read_byte(void)
{
    uint8_t data = 0;
    IO_INPUT(); /* Přepnout pin na vstup */
    
    for (uint8_t i = 0; i < 8; i++) {
        /* DS1302 posílá data na sestupnou hranu předchozího cyklu, 
           takže čteme hned, pak pulzujeme */
        if (IO_READ()) {
            data |= (1 << i);
        }
        
        /* Pulz hodinami */
        SCLK_HIGH();
        _delay_us(1);
        SCLK_LOW();
        _delay_us(1);
    }
    return data;
}

/* Zapíše data na konkrétní adresu/příkaz */
static void ds1302_write_reg(uint8_t cmd, uint8_t data)
{
    CE_LOW();
    SCLK_LOW();
    CE_HIGH(); /* Zahájení komunikace */
    
    ds1302_write_byte(cmd);
    ds1302_write_byte(data);
    
    CE_LOW(); /* Ukončení */
}

/* --- Public API (implementace rtc.h) --- */

int rtc_init(void)
{
    /* Nastavení směrů pinů */
    DS_DDR |= (1 << PIN_CE) | (1 << PIN_SCLK); // CE a SCLK vždy output
    CE_LOW();
    SCLK_LOW();

    /* 1. Vypnout ochranu proti zápisu (Write Protect), aby šlo zapisovat */
    ds1302_write_reg(CMD_WRITE_WP, 0x00);

    /* 2. Zkontrolovat Clock Halt (CH) bit v sekundách */
    /* Přečteme sekundy */
    CE_HIGH();
    ds1302_write_byte(CMD_READ_SEC);
    uint8_t seconds = ds1302_read_byte();
    CE_LOW();

    /* Pokud je bit 7 (CH) nastaven na 1, oscilátor stojí. Musíme ho spustit. */
    if (seconds & 0x80) {
        ds1302_write_reg(CMD_WRITE_SEC, 0x00); // Spustí hodiny a nastaví 0 sekund
    }

    return 0; // Úspěch
}

int rtc_set_time(const rtc_time_t *t)
{
    /* DS1302 vyžaduje zrušit Write Protect před každým velkým zápisem */
    ds1302_write_reg(CMD_WRITE_WP, 0x00);

    CE_HIGH();
    ds1302_write_byte(CMD_WRITE_BURST); // Příkaz pro zápis všeho najednou
    
    ds1302_write_byte(bin2bcd(t->ss)); // Sekundy
    ds1302_write_byte(bin2bcd(t->mm)); // Minuty
    ds1302_write_byte(bin2bcd(t->hh)); // Hodiny (24h formát)
    ds1302_write_byte(bin2bcd(1));     // Den (datum) - dummy
    ds1302_write_byte(bin2bcd(1));     // Měsíc - dummy
    ds1302_write_byte(bin2bcd(1));     // Den v týdnu - dummy
    ds1302_write_byte(bin2bcd(24));    // Rok (2024) - dummy
    ds1302_write_byte(0x00);           // Write protection disable (znovu pro jistotu)
    
    CE_LOW();
    return 0;
}

int rtc_get_time(rtc_time_t *t)
{
    CE_HIGH();
    ds1302_write_byte(CMD_READ_BURST); // Příkaz pro čtení všeho najednou
    
    uint8_t sec = ds1302_read_byte();
    uint8_t min = ds1302_read_byte();
    uint8_t hrs = ds1302_read_byte();
    
    /* Zbytek dat nás teď nezajímá, ale musíme ukončit komunikaci */
    CE_LOW(); 
    
    /* Převod a maskování CH bitu (bit 7 u sekund) */
    t->ss = bcd2bin(sec & 0x7F);
    t->mm = bcd2bin(min & 0x7F);
    
    /* Hodiny - ošetření 12/24 módu (bit 7) */
    /* DS1302: bit 7 = 12/24. Pokud 0, je to 24h. Pokud 1, je to 12h. */
    if (hrs & 0x80) {
        /* 12h mód (zjednodušeno - předpokládáme, že používáš 24h) */
        t->hh = bcd2bin(hrs & 0x1F); 
    } else {
        t->hh = bcd2bin(hrs & 0x3F);
    }

    return 0;
}