#ifndef RTC_H
#define RTC_H

#include <stdint.h>

/* Simple time structure used project-wide */
typedef struct {
    uint8_t hh;   /* hours  (0..23) */
    uint8_t mm;   /* minutes (0..59) */
    uint8_t ss;   /* seconds (0..59) */
} rtc_time_t;

/* Global (shared) RTC time variable */
extern volatile rtc_time_t g_time;

/* Initialize RTC module */
int rtc_init(void);

/* Read current time into provided struct */
int rtc_get_time(rtc_time_t *t);

/* Set time to start the oscillator and update RTC */
int rtc_set_time(const rtc_time_t *t);

#endif /* RTC_H */